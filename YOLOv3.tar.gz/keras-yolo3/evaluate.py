#! /usr/bin/env python

import argparse
import json
import pickle as pckl
from generator import BatchGenerator
from utils.utils import evaluate
from yolo3.yolo import YOLO


def load_model(model_path, classes_path, anchors_path):

    yolo = YOLO(
        **{
            "model_path": model_path,
            "anchors_path": anchors_path,
            "classes_path": classes_path,
            "score": 0.25,
            "gpu_num": 1,
            "model_image_size": (416, 416),
        }
    )

    return yolo


def _main_(args):
    config_path = args.conf

    with open(config_path) as config_buffer:    
        config = json.loads(config_buffer.read())

    instances = pckl.load(open(config['model']['dataset_folder'], 'rb'))
    labels = config['model']['labels']
    labels = sorted(labels)
   
    valid_generator = BatchGenerator(
        instances           = instances,
        anchors             = config['model']['anchors'],   
        labels              = sorted(config['model']['labels']),
        downsample          = 32, # ratio between network input's size and network output's size, 32 for YOLOv3
        max_box_per_image   = 0,
        batch_size          = config['train']['batch_size'],
        min_net_size        = config['model']['min_input_size'],
        max_net_size        = config['model']['max_input_size'],   
        shuffle             = True, 
        jitter              = 0.0, 
        norm                = None
    )

    infer_model = load_model(config['train']['model_folder'], config['train']['classes_path'], config['train']['anchors_path'])

    # compute mAP for all the classes
    average_precisions = evaluate(infer_model, valid_generator)

    # print the score
    for label, average_precision in average_precisions.items():
        print(labels[label] + ': {:.4f}'.format(average_precision['AP']))
    print('mAP: {:.4f}'.format(sum(average_precisions['AP'].values()) / len(average_precisions['AP'])))

if __name__ == '__main__':
    argparser = argparse.ArgumentParser(description='Evaluate YOLO_v3 model on any dataset')
    argparser.add_argument('-c', '--conf', help='path to configuration file')    
    
    args = argparser.parse_args()
    _main_(args)
