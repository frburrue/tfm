# Keras YOLOv3 [![license](https://img.shields.io/github/license/mashape/apistatus.svg)](LICENSE)

This part of the repo is copied from [**qqwweee/keras-yolo3**](https://github.com/qqwweee/keras-yolo3): **A Keras implementation of YOLOv3 (Tensorflow backend)**. 

All contents of this subfolder are under MIT license. 
